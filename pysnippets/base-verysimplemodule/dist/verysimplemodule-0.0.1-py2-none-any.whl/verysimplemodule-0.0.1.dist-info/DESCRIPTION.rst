My first Python package with a slightly longer description


